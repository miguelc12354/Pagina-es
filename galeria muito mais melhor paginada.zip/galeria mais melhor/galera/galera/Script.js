const gifsPerPage = 6;
let currentPage = 1;

const gifs = [
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSpyQrEzYZRPQzUy47lo1TqQGFzJsAZoydmsA&s",
    "https://play-lh.googleusercontent.com/VxUyAlymIKRRQt3dlZklsiyapiPh6kPEVnRl9wKSmLXAFHu9jiENWO44VuhNwGLVMLU",
    "https://static-00.iconduck.com/assets.00/brave-browser-icon-2048x2048-2d3r96ai.png",
    "https://t.ctcdn.com.br/lvns56iaSMyHvyTur4JeYS_NYeY=/i606944.png"
];

function showPage(page) {
    const start = (page - 1) * gifsPerPage;
    const end = start + gifsPerPage;
    const gifsToShow = gifs.slice(start, end);

    const gifContainer = document.getElementById('gif-container');
    gifContainer.innerHTML = '';
    gifsToShow.forEach(gif => {
        const img = document.createElement('img');
        img.src = gif;
        gifContainer.appendChild(img);
    });

    document.getElementById('page-info').innerText = `Page ${page}`;
    document.getElementById('prev').disabled = page === 1;
    document.getElementById('next').disabled = end >= gifs.length;
}

document.getElementById('prev').addEventListener('click', () => {
    if (currentPage > 1) {
        currentPage--;
        showPage(currentPage);
    }
});

document.getElementById('next').addEventListener('click', () => {
    if (currentPage * gifsPerPage < gifs.length) {
        currentPage++;
        showPage(currentPage);
    }
});

showPage(currentPage);

